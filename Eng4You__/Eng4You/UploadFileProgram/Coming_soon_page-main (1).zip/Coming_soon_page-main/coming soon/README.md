# HTML 5 Responsive Coming Soon Under Construction Template

![mockup](https://github.com/nipanimaju/coming-soon/blob/master/mockup.jpg?raw=true "mockup")

[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg?logo=paypal)](https://www.paypal.com/paypalme/nipanimaju)

* Licensed under [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/)
* Edit the HTML and JS to fit your needs.
* The JS file contains the target date, in first line (format "yyyy-mm-dd").
* The HTML file contains all texts and social media account links.
* Plenty of comments included. ;)


Buy me a coffee: [![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg?logo=paypal)](https://www.paypal.com/paypalme/nipanimaju)
