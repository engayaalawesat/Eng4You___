# Coming_soon_page
Comming soon Landing Page
<p align="center">
    <img src="https://github.com/Ananya-0306/Coming_soon_page/blob/main/coming%20soon/mockup.jpg" alt="coming soon landing page" />
</p>
