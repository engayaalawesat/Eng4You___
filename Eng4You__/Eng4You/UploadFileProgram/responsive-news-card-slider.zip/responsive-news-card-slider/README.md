# Responsive News Card Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/JavaScriptJunkie/pen/ZMMRRQ](https://codepen.io/JavaScriptJunkie/pen/ZMMRRQ).

I builth another Card Slider for news and blog pages etc with swiper.js. I made sweet animations when mouse hover and slide changes. Also all of them responsive.